class BasicMath
  def initiliaze

  end
  def self.sum value1,value2
    return value1+value2
  end
end